# OS-EX-1-Assembling-the-System---CASE-STUDY
OS-EX-1-Assembling-the-System---CASE-STUDY
## AIM:
To assemble the components of the computer.

## PROCEDURE:
1.Open the case:The First Step In Assembling A Computer Is To Open The Computer Case. To Open The Case, First Remove The Screws Of The Left Side Cover And Slide The Side Cover.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/2ffbb5d0-2909-4a87-be69-f1347695627b)


2.Install the power supply:The next step is to install a power supply. There are usually four screws that attach the power supply to the case.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/b6fa0cc6-454b-480c-ba78-341bcfaba254)


3.Attach the components to motherboard : The motherboard has to be prepared before its installation. To prepare the motherboard,you first need to install the CPU, then the Heat Sink on the CPU and CPU fan.A CPU socket uses a series of pins to connect a CPU’s processor to the Pc’s motherboard. If a CPU is connected via a CPU socket.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/b4fa1eb3-3f26-4041-944f-5bc338e45689)


4.A CPU socket uses a series Of pins to connect a CPU’s processor to the Pc’s motherboard. If a CPU is connected via a CPU socket.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/31fa2c18-e94e-4a38-afbd-ea653315f563)


5.Heat sink and fan assembly : A HeatSink And Fan (HSF) Is An Active Cooling Solution Used To Cool Down Integrated Circuits In Computer Systems, Commonly The Central Processing Unit (CPU).

6.Connect The Assembly Power Cable To The CPU Fan Connector On The Motherboard.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/e85a0b14-8b3e-43c8-a00a-050120ec094f)


7.Installation of RAM:To Install The RAM First On The Motherboard And Then Fix The Motherboard In The Case. To Install RAM, First Ensure Its Compatibility With The Motherboard.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/78a6f867-4fce-4667-8db0-386536f88553)


8.Install motherboard : After Preparing The Motherboard, You Can Install In The Computer Case.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/54e995b4-0d40-4077-aeb3-7a11e666be22)


9.Install internal drives: The Hard Drive Is The Device Which Stores All The Data. Connect The Power Cable Coming From The SMPS To The Power Socket Of Hard Disk Drive. Connect SATA Data Cable From Hard Disk Drive Socket To The Motherboard Socket.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/e80dc093-4ea7-4b76-b36f-d8ea036e9c19)


10.Connect all internal cables:Power Cables Are Used To Distribute Electricity From The Power Supply To The Motherboard And Other Components. Data Cables Transmit Data Between The Motherboard And Storage Devices, Such As Hard Drives.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/fd17a094-180d-4a22-846f-6e7a3924e0a0)


10.Install motherboard power connections:The Advanced Technology Extended (ATX) Main Power Connector Will Have Either 20 Or 24 Pins.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/655fc6d0-9029-46dc-8dc1-53b3001a0a48)


11.Connect external cables to the computer.The VGA Cable Is Used To Connect To Monitor.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/f6847dd3-f507-401a-bb3b-4e6b0877f038)


12.Push the power button to start the computer.

![image](https://github.com/Afsarjumail/OS-EX-1-Assembling-the-System---CASE-STUDY/assets/118343395/5b9497dc-f219-44af-aa8e-a3f443420f9b)

## RESULT:
Hence ,the system is successfully set up.
